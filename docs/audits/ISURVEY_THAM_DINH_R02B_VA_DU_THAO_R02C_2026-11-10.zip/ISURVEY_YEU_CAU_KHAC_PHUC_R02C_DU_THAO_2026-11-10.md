# PHIẾU YÊU CẦU KHẮC PHỤC R02C (ĐỀ XUẤT, CHƯA ĐƯỢC CHỦ DỰ ÁN PHÊ DUYỆT)

**Repository:** `D:\AIProject\isurvey`  
**Đầu vào:** R01 + R02 + R02B, báo cáo `ISURVEY_THAM_DINH_DOC_LAP_R02B_2026-11-10.md`.  
**Trạng thái:** tài liệu đề xuất chuẩn bị; **chỉ thực hiện khi chủ dự án chấp thuận**.  
**Phạm vi được đề xuất:** kiểm toán C# và giao diện **CHỈ ĐỌC**, chỉ tạo tài liệu mới trong `docs/audits/2026-11-10_ISURVEY_VIDEO_FACTORY_SOURCE_AUDIT_R02C/`.

## Phần kế thừa: KHÔNG làm lại từ đầu
- Giữ thống kê R02B, bản đồ lệnh/alias, bảng diff Git và năm hồ sơ ưu tiên đã có bằng chứng.
- Không tự mặc định 63 là số tính năng nghiệp vụ cuối cùng.

## 5 điều kiện bắt buộc để đóng Phase 01

**01. Chuẩn hóa `business_feature_id` bền vững:** AUD là ID tài liệu theo đợt, không dùng làm feature key. Tạo mã ổn định, bảng phiên bản R01/R02/R02B và bảng quyết định gộp/tách có dẫn chứng. Kiểm tra lại các cặp wrapper trong R02B và các điểm UI-only.

**02. Ánh xạ 91 XAML event:** với từng dòng, bắt buộc có parent feature (hoặc giải thích rõ vì sao là màn hình/công cụ nội bộ không cần feature độc lập), đường dẫn handler và side effect, lý do/độ tin cậy. Sửa phân loại `Confirm_Click`, `Save_Click`, `Update_Click`, `Create_Click`, `Start_Click`, `BtnExport_Click` không dùng từ khóa `close/cancel` trong body làm quyết định chính. CSV không có hàng thiếu `parent_feature_id` mà không có lý do.

**03. Sửa phân loại STUB:** dò đúng trong method body không ăn sang method liền kề; kiểm lại toàn bộ 125 command và các alias. Bắt buộc xác minh `ISURVEY_UAV_SEND_BACK` (current extractor gán STUB dù body trích gọi `UavImageService.SendImageToBack`). Giải thích chênh lệch số STUB và video candidates sau sửa; nêu các stub có Ribbon vẫn bật, không tự sửa Ribbon.

**04. Truy vết service và kết quả từng tính năng:** mỗi feature thực sự dành cho người dùng phải có call chain từ UI/command đến service/helper và side effect, inputs/outputs/error/authorization/destructive/independent baseline với file:line. `SERVICE_CHAIN_VERIFIED_STATIC` chỉ khi theo được chuỗi liên quan đến hậu điều kiện, không dùng logic chỉ mở tối đa 8000 ký tự đầu tệp. Nếu thiếu phải đánh `NOT_ENOUGH_EVIDENCE` và liệt kê chức năng/mắt xích cần đọc thêm. Có bảng coverage đo được, không ghi 100% khi chưa đủ.

**05. Chứng minh bao phủ và bất biến mã nguồn:** kiểm tra thêm context menu, dynamic UI, routed commands, command bindings, action invocation khác ngoài 91 Click khi có trong source; mapping rõ những nguồn loại trừ. Kèm `git HEAD/status/diff` trước–sau và danh sách tệp tạo mới. Không ghi đè R01–R02B.

## Đầu ra tối thiểu
1. `01_R02C_SUMMARY_AND_ACCEPTANCE.md` — phạm vi, số liệu sau chỉnh, kết luận từng điều kiện.
2. `02_BUSINESS_FEATURE_CATALOG.csv` — business_feature_id ổn định, source references, status & evidence.
3. `03_R01_R02_R02B_R02C_CROSSWALK.csv` — chỉ rõ ID cũ nào trỏ nghiệp vụ nào; tránh trùng mã giả.
4. `04_UI_EVENT_TO_FEATURE.csv` — XAML/Ribbon/Palette/Context/dynamic mapping đầy đủ.
5. `05_SOURCE_TRACE_COVERAGE.csv` và hồ sơ truy vết chi tiết — call chain/file:line, input, output, branch, hậu điều kiện, unresolved.
6. `06_STUB_RECHECK.csv` — từng command + bằng chứng phân loại, bao gồm ISURVEY_UAV_SEND_BACK.
7. `07_GIT_BEFORE_AFTER_AND_SECURITY.md` — logs và cam kết phạm vi chỉ đọc.
8. `08_OPEN_ISSUES_AND_STOP_GATE.md` — phần chưa đủ bằng chứng, tiêu chí chặn nghiệm thu.

**Giới hạn:** Không chỉnh C#/XAML/config/fixture thực, không build/test/CAD/NETLOAD, không sửa Windows/Drive/YouTube, không xuất hay gửi secret/license/dữ liệu công trình, không triển khai Video Factory, không tự chọn pilot hay đánh dấu Phase 01 được nghiệm thu. Nén báo cáo, DỪNG, chờ Chủ dự án thẩm định.
