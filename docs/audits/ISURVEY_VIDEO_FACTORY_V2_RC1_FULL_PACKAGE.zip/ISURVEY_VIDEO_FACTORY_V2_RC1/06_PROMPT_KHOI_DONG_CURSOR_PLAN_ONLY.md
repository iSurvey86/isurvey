# PROMPT KHỞI ĐỘNG CURSOR — D1 PLAN ONLY / READ ONLY

**Copy nguyên nội dung bên dưới vào Cursor, sau khi đính kèm các tài liệu v2.0-RC1 và được Chủ dự án cho phép bước D1.**

--- BEGIN PROMPT FOR CURSOR ---

**TEAM DEV CURSOR — iSURVEY VIDEO FACTORY — D1: THIẾT KẾ TRIỂN KHAI CÓ KIỂM SOÁT**

Workspace: `D:\AIProject\isurvey`.

Chủ dự án đã nghiệm thu **có điều kiện** Phase 01 kiểm toán nguồn và cho phép **soạn bộ quy tắc / Prompt Master triển khai**. Chúng tôi cung cấp phiên bản v2.0-RC1 gồm:

- `00_README_BAN_GIAO.md`
- `01_QUY_TAC_BAT_BUOC_V2_RC1.md`
- `02_PROMPT_MASTER_CURSOR_V2_RC1.md`
- `03_LO_TRINH_TRIEN_KHAI_CONG_NGHIEM_THU.md`
- `04_HOP_DONG_DU_LIEU_TRANG_THAI.md`
- `05_DOI_CHIEU_KIEM_TOAN_VA_TAI_LIEU_CU.md`
- `07_MAU_BAO_CAO_GATE.md`
- Gói nguồn `2026-11-10_ISURVEY_VIDEO_FACTORY_SOURCE_AUDIT_FINAL_MANUAL.zip` hoặc thư mục đã giải nén, nếu sẵn trong workspace.

**BƯỚC HIỆN TẠI: CHỈ THIẾT KẾ / PLAN ONLY. KHÔNG ĐƯỢC TRIỂN KHAI.**

1. Đọc toàn bộ bộ tài liệu, xác nhận nắm được ưu tiên KT-01..KT-07, KT-09, KT-08 vẫn hoãn. Nếu tài liệu v1.0 trái các quyết định này, liệt kê mâu thuẫn và áp dụng v2.
2. Đọc trạng thái repository hiện tại: branch, HEAD, trạng thái các tệp đã thay đổi **không được sửa bất kỳ tệp nào**. Không tự `checkout/reset`, không chép rules vào `.cursor/rules` khi chưa cho phép.
3. Kiểm tra hiện trạng solution C# iSurvey, các công cụ `tools/video` cũ, vùng `docs/video`, cấu hình plugin/bundle liên quan. **Không tự giả định source C# đã runtime verified**.
4. Dùng baseline Phase 01: 52 hồ sơ USER, 10 `SOURCE_SUPPORTED`, 42 `PARTIAL_BLOCKED`, 52 `NOT_TESTED`. Không được nâng trạng thái; không chọn pilot như đã được duyệt.
5. Đề xuất kiến trúc **tách biệt** mới cho Video Factory và các lựa chọn công nghệ dựa trên dependency thực tế. Đánh giá điểm mạnh/yếu của giải pháp capture, TTS, video composer, durable journal, credentials. Nếu chưa có số liệu benchmark/license thì ghi `UNKNOWN`, không khẳng định.
6. Đề xuất đường dẫn module và file allowlist cho **slice I1 đầu tiên**: chỉ hợp đồng dữ liệu, feature registry, event journal, state machine, pure tests; tuyệt đối không sửa nghiệp vụ iSurvey. Đề xuất rollback, test plan, và yêu cầu phê duyệt tương ứng.
7. Lập danh mục P0 về màn hình Dell tắt vật lý và quay 4K AutoCAD thật, Windows lock/Sleep, iSurvey bundle/version, CAD fixture/reference, license/UPS/SSD/Drive/YouTube để kiểm chứng ở các slice kế tiếp. Không tự chạy các phép thử đó trong D1.
8. Lập kế hoạch theo chặng D1→I1→I2→I3→I4→I5, nêu STOP gates, danh sách 15 bài NT, người/phạm vi duyệt ở mỗi gate. Không tự chạy I1 sau khi nộp kế hoạch.

**BÀN GIAO TRONG CHAT, KHÔNG TẠO TỆP TRONG REPO Ở D1:**

A. TÓM TẮT: source SHA, workspace hiện tại, đã đọc gì, còn thiếu gì.
B. SƠ ĐỒ KIẾN TRÚC đề xuất; module boundaries, data flow, provenance, backup và quyền.
C. TÁI SỬ DỤNG: bảng hiện trạng `tools/video`/docs cũ: giữ, bỏ, cần thử lại, lý do có source path:line.
D. KẾ HOẠCH SLICES: I1..I5, file allowlist, acceptance tests, risk, rollback, phạm vi quyền.
E. `I1_TASK_PROPOSAL` hoàn chỉnh: TASK_ID, current base SHA, allowed paths, forbidden paths/actions, expected artifacts, test plan, STOP conditions.
F. `UNKNOWN/BLOCKERS`: P0/P1; không suy đoán giấy phép, UPS, 4K monitor off, hiệu năng.
G. BẰNG CHỨNG: dẫn chứng tệp/dòng từ repo thực tế khi đã kiểm tra được.
H. LỜI CAM KẾT: không sửa file, không build, không chạy CAD, không truy cập cloud, không tự triển khai.

**KẾT THÚC: STOP TẠI GATE D1.** Chờ Chủ dự án thẩm định trước khi được quyền viết code Slice I1.

Nếu môi trường Cursor có thể tự sửa file dù ở Agent mode, hãy thực hiện ở chế độ hỏi/đọc-only và kiểm tra diff; không tự tạo tài liệu hoặc mã nguồn trong repo ở giai đoạn này.

--- END PROMPT FOR CURSOR ---
