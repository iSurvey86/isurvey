# ĐỐI CHIẾU QUYẾT ĐỊNH, KIỂM TOÁN PHASE 01 VÀ TÀI LIỆU CŨ

**Phiên bản:** v2.0-RC1 · 10/11/2026  
**Mục tiêu:** Ngăn Cursor dựa vào draft/Excel/video tools cũ để thay đổi các quyết định đã chốt. Các bảng bên dưới là đối chiếu từ thông tin dự án và gói kiểm toán, **không chứng minh tình trạng runtime**.

## A. Bảng đối chiếu KT-01..KT-09

| Quyết định | Bất biến/điểm áp dụng trong v2 | Quy tắc / hợp đồng |
|---|---|---|
| KT-01 | Thư viện fixtures chung, versioned, immutable; có canonical masters cho trường hợp đặc thù | Q04, Contract §1, §7 |
| KT-02 | Synthetic/regenerable; independent expected; MASTER không sửa; WORK COPY mới mỗi lần; tải fixture ngoài chỉ khi được phép | Q04, Contract §2 |
| KT-03 | CAD API/commands/UI/keyboard có observer & postconditions; không replay mutations không rõ trạng thái | Q05, Q10, Contract §5 |
| KT-04 | Workstation hiện tại trước; phân biệt Dev/Release/Video Production; có rollback & gate; không đồng nghĩa tách vật lý ngay | Q01, roadmap D1/I1 |
| KT-05A–D | Đọc code, xác minh installed plugin, 100% user-facing behavior có bài học; feature–lesson–video many-to-many; không 1 lệnh/1 video; admin OTP không public | Q02, Q03, Q06 |
| KT-06A–C | Orchestrator một active job, footage AutoCAD thật, preflight, source/fixture/work copy, không sửa business C# | Q03–Q05, Master E/F |
| KT-06D | Nam Bắc TTS; glossary; phụ đề riêng; **không duyệt từng script**; duyệt giọng sau hai video trial hoàn chỉnh | Q06 |
| KT-06E | Không sửa nội dung nghiệp vụ bằng hậu kỳ; Master 4K, preview1080; branding đã chọn, nguồn xác thực | Q06, Contract §7 |
| KT-06F | G1–G4; G4 `Production Complete` trên local; Drive chỉ copy one-way; G5/version, upload & publish quyền riêng | Q07–Q08, Contract §3–§4 |
| KT-07.1 | V1 standard/master còn DRAFT; chủ dự án quyết định mới có hiệu lực cao hơn | README §4 |
| KT-07.2 | Provenance, checksum/version, fine-grained invalidation | Q02, Contract §1/§6 |
| KT-07.3 | Trục Production/QA/G5/Drive/Upload/Publication độc lập | Q07, Contract §3 |
| KT-07.4 | Các giai đoạn production → Drive → handoff **tuần tự**, thời hạn handback biến thiên và margin động | Q09 |
| KT-07.5 | Recovery an toàn, không replay ambiguous CAD side effects, failure isolation | Q10, Contract §5 |
| KT-07.6 | 2 trial, ca đêm, mất mạng/điện, restore, YouTube/Drive, xác minh bằng test thực | Roadmap NT01–15 |
| KT-07.7 | KT-07 đóng cấp kiến trúc, chưa runtime validated | README §1 |
| KT-08 | Marketing/doanh thu **tạm hoãn, giữ số KT-08** | Master B |
| KT-09.1 | Least privilege, OWNER approvals, engineer early handoff | Q01 |
| KT-09.2 | Windows security, monitor physical-off, interactive CAD & no bypass, App Control, Sleep/lock risk | Q05, Q09, Q11 |
| KT-09.3 | Proactive budget/storage/API and no autonomous purchases/deletes | Q11 |
| KT-09.4 | Ca có bàn giao, deadline động, trạng thái machine/window, trả máy | Q09 |
| KT-09.5 | Backup tiered, verified restore, checksums/durable checkpoints, UPS uncertain | Q08/Q10 |
| KT-09.6 | 6 cấp nghiệm thu, 15 bài NT, 4 trạng thái minh bạch | Q12, roadmap §5 |
| KT-09.7 | Đóng KT-09 cấp kiến trúc có điều kiện kiểm chứng | README §1 |

## B. Kết quả FINAL_MANUAL — nguồn baseline, không mở rộng tùy ý

Đường dẫn gói audit: `2026-11-10_ISURVEY_VIDEO_FACTORY_SOURCE_AUDIT_FINAL_MANUAL.zip`.

- Có 52 hồ sơ tính năng `USER` với BF IDs không trùng trong chính snapshot.
- Trong 52 có **10 `SOURCE_SUPPORTED` và 42 `PARTIAL_BLOCKED`**. **Tất cả 52 runtime `NOT_TESTED`.**
- Bảng `02_FEATURE_DISPOSITION_52_USER.csv` là căn cứ baseline về quyền/chặn; không thay bằng R01 150 dòng, R02 79 dòng, R02B/C 63 hồ sơ hoặc 52 ứng viên video.
- 10 SOURCE_SUPPORTED ở mức được mô tả: `ISURVEY_CAD_TO_DGN`, `ISURVEY_DELETE_GE`, `ISURVEY_LOGOUT`, `ISURVEY_NUMBER_VERTICES`, `TAOTUYEN`, `THIETLAPCOC`, `TAOMOHINH`, `TRACAOD`, `ISURVEY_UAV_FRAME_TOGGLE`, `ISURVEY_UAV_SEND_BACK`. Không có mục nào được coi READY_TO_CAPTURE vì chưa runtime.
- Các feature P0 vẫn partial: DGN→CAD, VEMCD, MAP_SAT, một số hành vi xóa/tạo/ghi đè khác. Khi đến giai đoạn production phải xử lý theo từng feature (KHÔNG mở audit R02E đại trà).
- Khóa BF dạng `BF-<command>` cần migration registry khi nghiệp vụ gộp/tách/đổi tên; không tự tin là bất biến.
- Các tệp `03_EVIDENCE/E-*.md` là trích đoạn Cursor xuất; toàn bộ repo C# thực không có trong gói; khi cần có thể yêu cầu nhìn tại repo đúng SHA thay vì chép toàn bộ source ra ngoài.
- Mốc Git được báo cáo: nhánh `main`, commit `3a16cb3959dc4e65c08f77b6de26669b309739cd`; **Cursor phải xác minh lại hiện trạng** trước khi plan, không được tự checkout commit cũ.

## C. Sai lệch chính giữa tài liệu v1.0 và quyết định mới

| Tài liệu v1.0 hoặc công cụ cũ | Nội dung/di sản | Quy tắc mới có hiệu lực |
|---|---|---|
| `iSurvey_Video_Production_Standard_v1.0.md` | `BASELINE ĐỀ XUẤT`, video ngang thường 2–4 phút | KT-05: Feature 3–5, Workflow 5–8, linh hoạt theo nghiệp vụ |
| `iSurvey_Video_Prompt_Master_v1.0.md` | Phase01 được mô tả như chưa thực hiện và dừng trước pilot | Phase01 đã đóng có điều kiện; bước mới là D1 thiết kế, không lập lại audit tổng thể |
| Các bản v1.0 | Gate A/B/C & human approval có thể bị hiểu phải duyệt mọi script | G1–G4 = production completion; G5 owner exact video version; không duyệt từng script; Voice sau 2 videos trial |
| `iSurvey_Video_Schemas_v1.0.json` | Feature record / fixture / video / QA / approval chưa đủ trục | Thiết kế lại theo contracts Q07; không tự dùng schema cũ làm schema chuẩn chính thức |
| `QUY_TRINH.md` | Giọng `vi-VN-HoaiMyNeural` (không khớp nam Bắc); từng chức năng một video | KT-05/06: male northern voice, feature-lesson-video many-to-many |
| `YOUTUBE.md` | Script và OAuth có thể upload + change public | G5, Upload Authorization và Publication Authorization phải độc lập; không dùng token quyền rộng làm phê duyệt thay người |
| `CATALOG.md` | D2C 1.8.15 báo “đã ghép, chưa đăng” | Không có bằng chứng MP4 valid/G4 từ bộ audit; không đánh dấu factory video đã tồn tại |
| `Danh_sach_lenh_iSurvey*.xlsx` | Danh sách lệnh, trường “Hoàn thành” là dữ liệu quản lý nghiệp vụ | Không chứng minh source/runtime/coverage hay trạng thái video |
| `CR-01` | Nhiều khuyến nghị fixture native/synthetic hữu ích | Chỉ tái sử dụng sau đối chiếu KT-01/02 và không nâng draft thành approved tự động |

## D. Điểm thực tế máy cần xác minh (không dùng như runtime PASS)

- Windows 11 Pro for Workstations; CPU Ryzen Threadripper 9970X 32 core/64 thread; RAM 128GB; RTX 5090 ~32GB dedicated VRAM, không phải 136GB VRAM.
- Dell P3225QE 3840×2160 60Hz DisplayPort, **bị tắt bằng nút nguồn vật lý** sau giờ kỹ sư; recording 4K sau khi tắt = **UNKNOWN** cho tới khi thử thực.
- Samsung 990 PRO SSD C ~4TB, D/E mỗi ổ ~20TB HDD (tình trạng vật lý cần kiểm tra), G/H FAT32 không phù hợp master >4GB.
- Mixed DPI 200% user và 150% system; Windows App Control for Business enforced; DxDiag không nhận âm thanh mặc định lúc báo cáo.
- `iSurvey.bundle` trong `%AppData%\Autodesk\ApplicationPlugins\iSurvey.bundle` là **đường dẫn dự kiến cần xác nhận**, không chứng minh plugin đang nạp hoặc build/source khớp.
- Internet/UPS/license/BIOS auto-on/network throughput/voice API/right to publish đều **UNKNOWN** đến khi kiểm tra riêng.

## E. Quy tắc chống mở vòng kiểm toán vô hạn

1. Phase01 đã có quyết định đóng có điều kiện. Không yêu cầu scan lại 52 hồ sơ trong D1 chỉ để nâng nhãn.
2. Chỉ audit sâu **đúng feature mà slice/pilot sẽ động tới**, khi chuẩn bị per-feature verification; những feature khác vẫn BLOCKED.
3. Nếu có blocker hệ thống (ví dụ monitor tắt mất capture 4K), STOP đúng mô-đun và trình phương án kỹ thuật; không viết tiếp pipeline giả lập/không tuyên bố GO.
4. Khác biệt giữa “chưa đủ bằng chứng tĩnh” và “phần mềm có lỗi” phải được nêu rõ, không đánh đồng.
5. Không tự chọn D2C làm pilot vì CATALOG cũ ghi có video; tiêu chí chọn phải là fixture, reference, rủi ro mutation, UI, độ xác thực runtime, thời gian/chi phí.

**Kết luận:** Dùng KT-01..KT-07, KT-09 và 52 disposition Phase01 làm đầu vào triển khai có kiểm soát, không biến các tài liệu cũ thành quyền hoặc sự thật mới.
