# HỢP ĐỒNG DỮ LIỆU, TRẠNG THÁI VÀ CHỨNG CỨ

**Phiên bản:** v2.0-RC1 · 10/11/2026  
**Mục đích:** Hợp đồng logic để Cursor thiết kế typed schema ở I1, **không phải JSON Schema đã được viết/cài/test**. Các tên field bên dưới là **đề xuất triển khai**, cần D1 review. Nguyên tắc bất biến/permissions từ KT đã chốt.

## 1. Nguyên tắc ID / phiên bản

- `feature_key`: khóa nội bộ ổn định qua đổi tên lệnh, gộp/tách có migration; `BF-*` của Phase01 là baseline external link, không giữ làm ID cứng bằng cách suy `BF-<command>`.
- `lesson_id`: mục tiêu học tập/nhóm tính năng (Feature/Workflow/Update/Troubleshooting/Tips).
- `video_id`: định danh nội dung video; `video_revision_id`: phiên bản render bất biến; `run_id`: một lần thử/render; `scene_id`: cảnh trong manifest; không dùng một tên tệp để suy ID.
- `source_snapshot_id`: commit C# + binary/build/installed bundle thực, CAD host/môi trường test; khác version cần invalidation theo dependency.
- `fixture_id/version`: MASTER/WORK COPY/independent expected; mỗi WORK COPY thuộc `run_id` và chỉ dùng một lần/take.
- `approval_id`: người duyệt + loại quyết định + `artifact_checksum` + scope + timestamp; không chấp nhận phê duyệt chỉ bằng tên file.
- `artifact_id`: hash SHA-256 + loại + media metadata + provenance; dùng để chứng minh đúng file.

## 2. Các bản ghi logical bắt buộc

| Record | Required identity | Trường cốt lõi | Cấm suy luận |
|---|---|---|---|
| SourceSnapshot | source_snapshot_id | repo_sha, branch, build_id, installed_bundle_hash, CAD version, host environment, measured_at | repo_sha = installed plugin nếu chưa đối chứng |
| FeatureRecord | feature_key | baseline_bf_id, aliases, UI paths, source dispositions, evidence refs, hazard class, runtime status, fixture requirements, last_verified_snapshot | SOURCE_SUPPORTED ⇒ VERIFIED |
| LessonPlan | lesson_id | objectives, features[], audience, class, prerequisites, expected output | số lệnh = số lesson/video |
| FixtureManifest | fixture_id/version | master_hash, work_copy_path/run, independent_expected, unit, CRS, seed, native_object_requirements, tolerance, rights | rename DWG → DGN ⇒ native DGN |
| ScenarioManifest | video_revision_id | lesson/source/fixture versions, scene actions, assertions, audio/visual cues, evidence refs | command dispatched ⇒ completed |
| ActionEvent | run_id/sequence | precondition, command/UI action, started/completed, result, side_effects, evidence refs | no timeout ⇒ PASS |
| MediaArtifact | artifact_id | codec/frame rate/resolution/duration, SHA, source scenes, rights, kind (4K/preview/audio/SRT/VTT) | upscale 1080 ⇒ native 4K |
| GateReport | gate + video_revision_id | mandatory checks, evidence, pass/fail/unknown, reviewer | G4 depends on G5/Drive |
| ApprovalLedger | approval_id | approval_type, artifact_version/SHA, actor/time/scope, revocation | G5 ⇒ UploadAuth/PublishAuth |
| CopyLedger | delivery_id | local package, destination, checksum, attempt/remote ID, reconciled state | uploaded ambiguous ⇒ retry immediately |
| DurableJob | job_id/run_id | phases, current checkpoint, lease/owner, authorized shift, deadline, recoverability | checkpoint while CAD result ambiguous |
| CostResource | job/shift/month | budget authorization, measured usage, estimated quota/storage/time, stop threshold | auto-purchase/auto-delete |

## 3. Các trục trạng thái độc lập

**Không dùng một `status` tổng hợp duy nhất.** Schema đề xuất:

```json
{
  "source_disposition": "PARTIAL_BLOCKED",
  "runtime_verification": "NOT_TESTED",
  "production": "NOT_STARTED",
  "qa_g1_g4": {
    "g1": "NOT_TESTED",
    "g2": "NOT_TESTED",
    "g3": "NOT_TESTED",
    "g4": "NOT_TESTED"
  },
  "g5_owner_review": "NOT_REQUESTED",
  "drive_copy": "NOT_QUEUED",
  "upload_authorization": "NOT_GRANTED",
  "youtube_upload": "NOT_QUEUED",
  "publication_authorization": "NOT_GRANTED",
  "publication": "NOT_PUBLISHED"
}
```

**ĐÂY LÀ VÍ DỤ MINH HỌA KỸ THUẬT**, không phản ánh tình trạng của một video thật, không phải dữ liệu người dùng.

Trục production có thể đi `NOT_STARTED → PREPARING → CAPTURING → EDITING → QA_PENDING → PRODUCTION_COMPLETE`, thêm `PAUSED/BLOCKED/FAILED` với điều kiện. `PRODUCTION_COMPLETE` **chỉ** khi G4 PASS.

Các trục QA mandatory: `PASS | FAIL | NOT_TESTED | INSUFFICIENT_EVIDENCE`; owner review: `NOT_REQUESTED | PENDING | APPROVED | REJECTED | REVOKED`; Drive/YouTube: `NOT_QUEUED | QUEUED | IN_PROGRESS | RECONCILIATION_REQUIRED | VERIFIED | FAILED`. Đây là đề xuất tên enum; các phép chuyển phải có bằng chứng và quyền.

## 4. Điều kiện mở cổng

### ReadyToCapture predicate

```text
READY_TO_CAPTURE :=
  source_evidence_sufficient_for_claims
  AND source_binary_bundle_host_match
  AND runtime_result_verified_on_WORK_COPY
  AND independent_reference_pass
  AND CAD_side_effects_safe_or_explicitly_gated
  AND machine_session_approved_and_usable
  AND authorized_shift_and_time_budget_valid
  AND no_required_blockers
```

Không lưu tay một flag `ready=true` thiếu sự kiện; phải tính từ bằng chứng/hiệu lực phiên bản. Nếu runtime khác host/bundle, feature cần preflight mới.

### Production Complete predicate

```text
PRODUCTION_COMPLETE :=
  G4_PASS
  AND local_master_4k_verified
  AND local_preview_1080_verified
  AND subtitles_and_manifest_complete
  AND checksums_committed
```

Không đưa `G5`, `drive_copy`, `youtube_upload` vào predicate này.

### Publication predicate

```text
CAN_UPLOAD := G5_APPROVED_FOR_EXACT_REVISION
              AND UPLOAD_AUTHORIZATION_VALID_FOR_EXACT_REVISION
              AND YOUTUBE_ACCOUNT_SCOPE_ALLOWED

CAN_PUBLISH := UPLOAD_EXISTS_AND_VERIFIED
               AND PUBLICATION_AUTHORIZATION_VALID_FOR_EXACT_REVISION
               AND PLATFORM_PRIVACY_ACTION_ALLOWED
```

Đây là chính sách đề xuất thực thi theo quyền đã chốt; phải cân nhắc G5 `REVOKED`, version invalidation và thời hạn quyền.

## 5. Event log, idempotency, phục hồi

Mỗi side-effect event cần:

```json
{
  "event_id": "illustrative-event-id",
  "job_id": "illustrative-job-id",
  "run_id": "illustrative-run-id",
  "phase": "CAD_ACTION",
  "attempt_no": 1,
  "pre_state": "WORK_COPY_VERIFIED",
  "action": "CMD_EXECUTE",
  "side_effect_class": "PERSISTENT_CAD_MUTATION",
  "execution_status": "UNCERTAIN",
  "cad_observed_postcondition": null,
  "replay_allowed": false,
  "evidence_refs": []
}
```

*Các giá trị `illustrative-*` chỉ minh họa schema, không phải ID, không là log đã chạy.*

- Journal append-only; dùng fsync/atomicity hoặc biện pháp tương đương được đo/test trên Windows, không tự giả định mọi write durable.
- Bắt buộc `PREPARED` → `RUNNING` → `POSTCONDITION_VERIFIED` → `COMMITTED`; nếu ngắt giữa RUNNING và VERIFIED, trạng thái `UNCERTAIN`/`REQUIRES_RECONCILIATION` và **không tự replay** thao tác CAD có hiệu ứng.
- Với render/audio có thể retry nếu input immutable và destination temp đã được xử lý an toàn; retry không ghi đè master hợp lệ.
- Với Drive/YouTube upload không biết có thành công hay chưa, truy remote state bằng dấu vết/ID/hash trước khi tạo upload mới; không tự duplicate.
- State restore kiểm tra host session/lease/shift, quyền và data integrity trước khi tiếp tục.

## 6. Provenance graph và invalidation tối thiểu

```text
SourceSnapshot ─┐
FeatureRecord ──┼─> LessonPlan -> Scenario -> CAD Take -> Footage -> 4K Master
Fixture/Expected┘                       │             └──> Preview 1080
VoiceProfile ──> TTS Audio ─────────────┘             └──> SRT/VTT
                                                     └──> G1..G4
                                                          └──> G5 checksum
                                                          └──> Drive copy (optional)
                                                          └──> YouTube (authorized)
```

- Thay nguồn của **một feature** chỉ làm mất hiệu lực các lessons/scenes/videos phụ thuộc feature đó, không invalidation mọi video khác.
- Thay fixture chỉ làm mất hiệu lực run/take liên quan, nếu production reference thay đổi sẽ đánh giá downstream.
- Thay script/voice/timing ảnh hưởng audio/subtitle/composition/video SHA và G5 tương ứng; không sửa đối tượng CAD đã chứng minh nếu không cần.
- Thay Master checksum làm duyệt G5 cũ không còn áp dụng cho phiên bản mới; Drive copy/upload cũ vẫn ghi nhận bản cũ, không âm thầm ghi đè remote.
- Thay quy tắc G1–G4 phải có version của policy để tái đánh giá phù hợp.

## 7. Gói Delivery trên local SSD

**Đây là cấu trúc đề xuất, không phải thư mục repo hiện có:**

```text
local_authoritative_store/
  registry/                 # identity, versions, approval ledger
  immutable-fixtures/       # MASTER + expected baseline
  work-copies/<run-id>/     # chỉ bản sao bị tác động
  jobs/<job-id>/
    state/                  # durable events/checkpoints
    source-evidence/
    capture/raw/
    audio/
    captions/
    edit/
    qa/
    delivery/<video-revision-id>/
      master_3840x2160.mp4
      preview_1920x1080.mp4
      subtitles.srt
      subtitles.vtt
      video_manifest.json
      qa_report.json
      release_manifest.json
      SHA256SUMS.txt
```

Các thư mục/filename chỉ là mẫu cấu trúc và cần D1 thống nhất với cấu trúc repo/máy thật; không được tự tạo từ prompt đọc-only. Delivery được hoàn tất atomic từ staging sang release, không cho phép Drive copy từ staging dở dang.

## 8. Quyền, thiết bị và thời gian ca

Một Job phải có `authorized_window.start`, `authorized_window.handoff_deadline`, `handoff_owner`, `safety_margin_basis`, `machine_id`, `interactive_session_state`, `monitor_off_4k_validation_id`, `budget_policy_version`. Scheduler không chạy video khi các trường mandatory sai/thiếu.

- Sleep suppression chỉ trong ca được cho phép và được hoàn nguyên; không bypass Windows lock.
- Monitor physical off verification là bằng chứng runtime có version theo GPU driver/OS/display mode; đổi phần liên quan cần retest.
- `one_active_video_job` là invariant; Drive copy dùng stage riêng không tranh công đoạn sản xuất; có thể có nhiều production-complete videos chờ G5.
- Backup retention/RPO/RTO dựa nhu cầu và drill, không tự đặt ngưỡng số liệu thiếu khảo sát.

## 9. Kiểm soát giấy phép và thông tin nhạy cảm

- Secret reference là con trỏ vào OS credential vault/approved secret manager, không lưu token/plaintext trong video/JSON/git.
- Source and fixture packages cho viewer chỉ khi được phép và quét dữ liệu nhạy cảm.
- License iSurvey, AutoCAD/Civil 3D, font, TTS provider, codec, nhạc/ảnh, logo đều có quyền sử dụng; không tự nhúng media có bản quyền.
- Approval ledger và audit trail append-only về nghiệp vụ, không thể bị sửa âm thầm bởi upload script.

## 10. Kiểm thử contract tại I1

Ít nhất phải có test cho: duplicate feature ID; merge migration; source_disposition blocked; runtime NOT_TESTED; attempted G4 with missing subtitle/4K; G5 wrong checksum; upload auth missing; publish auth missing; replay CAD uncertain; Drive copy before G4; two active jobs; deadline budget insufficient; provenance invalidation; restore journal partial write; Google/YouTube quota API không bị giả lập thành thành công thật.

**Không chạy bất cứ test nào trong bước D1 read-only.** Test cases chỉ là **yêu cầu thiết kế**, phải được Chủ dự án cho phép thực hiện ở I1 trở đi.
