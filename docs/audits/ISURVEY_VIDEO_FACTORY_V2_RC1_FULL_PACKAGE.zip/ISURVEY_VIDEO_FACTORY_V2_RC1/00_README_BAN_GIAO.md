# iSurvey Video Factory — Gói kiến trúc triển khai v2.0-RC1

**Ngày lập:** 10/11/2026  
**Repository mục tiêu (do Chủ dự án cung cấp):** `D:\AIProject\isurvey`  
**Trạng thái:** **BẢN TRÌNH DUYỆT NỘI DUNG**, đã có quyết định cho phép *soạn* bộ quy tắc / Prompt Master; chưa có bằng chứng các tệp này đã được chép vào máy Windows hoặc Cursor đã thực hiện.  
**Phạm vi:** kiến trúc triển khai hệ thống **iSurvey Video Factory**, không phải thay thế/sửa tính năng nghiệp vụ của iSurvey.

## 1. Những gì đã chốt và chưa chốt

- KT-01–KT-07 và KT-09: kiến trúc đã được Chủ dự án phê duyệt; KT-08 marketing/doanh thu tạm hoãn, không đổi số.
- **Phase 01 — kiểm toán C#**: Chủ dự án ngày 10/11/2026 đã nghiệm thu **có điều kiện** và cho phép chuyển sang soạn tài liệu triển khai. Không tuyên bố toàn bộ tính năng đã xác minh.
- 52 hồ sơ USER trong bộ `FINAL_MANUAL`: 10 `SOURCE_SUPPORTED`, 42 `PARTIAL_BLOCKED`; **52/52 `NOT_TESTED` trên AutoCAD**. `SOURCE_SUPPORTED` KHÔNG đồng nghĩa `RUNTIME_VERIFIED`/`READY_TO_CAPTURE`.
- Bộ quy tắc/PROMPT này là bản đầu tiên tổng hợp các quyết định. **Chủ dự án có quyền duyệt nội dung và cấp quyền riêng từng bước cho Cursor.** Việc sở hữu gói tài liệu không tự cấp quyền chỉnh sửa source, chạy CAD, kết nối dịch vụ hoặc xuất bản.

## 2. Danh mục tệp — thứ tự đọc

1. `01_QUY_TAC_BAT_BUOC_V2_RC1.md` — luật vận hành và ranh giới bất biến; nguồn chuẩn nghiệp vụ trong gói.
2. `02_PROMPT_MASTER_CURSOR_V2_RC1.md` — prompt điều phối đa giai đoạn và hợp đồng báo cáo.
3. `03_LO_TRINH_TRIEN_KHAI_CONG_NGHIEM_THU.md` — lộ trình module, quyền thực thi, các điểm STOP/GO, NT-01..15.
4. `04_HOP_DONG_DU_LIEU_TRANG_THAI.md` — dữ liệu chuẩn, trạng thái độc lập, khóa nguồn/chứng cứ, sự kiện, lỗi, kiểm soát phát hành.
5. `05_DOI_CHIEU_KIEM_TOAN_VA_TAI_LIEU_CU.md` — đối chiếu quyết định, khác biệt với bản v1.0, kết quả Final Manual, việc còn thiếu.
6. `06_PROMPT_KHOI_DONG_CURSOR_PLAN_ONLY.md` — **văn bản dán vào Cursor ngay sau khi chủ dự án quyết định kích hoạt bước thiết kế**.
7. `07_MAU_BAO_CAO_GATE.md` — mẫu báo cáo phải nộp ở mỗi STOP gate.
8. `REFERENCE_PHASE01/` — snapshot hai tệp kiểm toán cuối (kết luận/ma trận 52); chi tiết Git vẫn ở ZIP gốc FINAL_MANUAL; dùng đối chiếu, không tự tuyên bố runtime.
9. `CURSOR_RULES_STAGING/.cursor/rules/*.mdc` — hai quy tắc Cursor dạng native, **STAGING** (chưa cài vào repo).
10. `SHA256SUMS.txt` — mã băm để đối chiếu tệp bàn giao (được tạo cùng ZIP).

## 3. Cách dùng không làm thay đổi repo

1. Tải và giải nén gói tại một thư mục **ngoài repository iSurvey** để lưu bản phê duyệt, không giải nén đè vào gốc `D:\AIProject\isurvey`.
2. Chủ dự án xem xét và xác nhận nội dung v2.0-RC1 nếu muốn dùng làm chuẩn chính thức. Khi duyệt, sao lưu định danh bản tài liệu và mã băm.
3. Nếu cho phép cài Rules, **kiểm tra trước `.cursor/rules/` đã có tệp nào**, xem diff rồi chỉ thêm hai `.mdc` trong staging, không xóa/ghi đè rule khác. Với repo hiện có, việc chép tệp là hành động thay đổi repo và cần quyền riêng.
4. Trước khi giao Cursor làm việc, dùng `06_PROMPT_KHOI_DONG_CURSOR_PLAN_ONLY.md` cùng các tài liệu quy tắc. Chỉ chạy ở chế độ Ask/Plan không thực thi thay đổi; **chưa chép file hoặc chạy lệnh bằng quyền Agent** nếu không có phê duyệt.
5. Cursor trả báo cáo đề xuất kỹ thuật và STOP. Không tự làm tiếp module 01 sau khi gửi kế hoạch.

## 4. Thứ bậc hiệu lực

1. Chỉ đạo mới nhất của Chủ dự án tại đúng phạm vi đã được phê duyệt.
2. Các quyết định kiến trúc KT-01..KT-07, KT-09 và điều kiện nghiệm thu Phase 01.
3. `01_QUY_TAC_BAT_BUOC_V2_RC1.md`, sau khi Chủ dự án duyệt nội dung.
4. Prompt Master và các prompt từng giai đoạn được cấp quyền.
5. Schema/biểu mẫu/nhật ký kiểm toán có nguồn gốc đã xác minh.
6. `iSurvey_Video_Production_Standard_v1.0.md`, `iSurvey_Video_Prompt_Master_v1.0.md`, `CR-01` và các tài liệu video cũ: **THAM KHẢO, KHÔNG CÓ QUYỀN GHI ĐÈ QUYẾT ĐỊNH MỚI**.

Nếu hai tài liệu cùng hiệu lực nhưng mâu thuẫn: **STOP và báo đúng điều khoản**, không tự dung hòa theo ý của Cursor.

## 5. Nguồn đã đối chiếu khi soạn

- Gói `2026-11-10_ISURVEY_VIDEO_FACTORY_SOURCE_AUDIT_FINAL_MANUAL.zip`, CSV `02_FEATURE_DISPOSITION_52_USER.csv`, 4 đầu ra và trích đoạn C#.
- `ISURVEY_THAM_DINH_FINAL_MANUAL_PHASE01_2026-11-10.md`.
- Các vòng thẩm định R01/R02/R02B/R02C/R02D và kết luận của Chủ dự án.
- Hai tệp cấu hình máy và tài liệu video v1.0; các quyết định KT-01–KT-09 trong lịch sử hội thoại.

**Giới hạn kiểm chứng:** Chưa truy cập trực tiếp repo cục bộ tại `D:\AIProject\isurvey`; không cam kết đường dẫn, build, phiên CAD, tốc độ GPU, EDID/Dell monitor, UPS hay quyền OAuth đang hoạt động. Không có kết quả runtime của dây chuyền mới.

## 6. Mốc kế tiếp và đề xuất quyết định

**GATE D0 — Duyệt bộ quy tắc và Prompt Master:** kiểm tra tài liệu.  
**GATE D1 — Duyệt thiết kế triển khai và quyền tạo nhánh/module:** Cursor nộp plan read-only trước; chưa làm code.  
**GATE I1..:** chỉ làm từng slice được phê duyệt, trên nhánh cho phép, có test và bằng chứng; không sửa C# nghiệp vụ.

Không đồng nhất việc đóng Phase 01, duyệt tài liệu, duyệt lập trình, duyệt test CAD và duyệt phát hành; đó là những quyết định độc lập.
