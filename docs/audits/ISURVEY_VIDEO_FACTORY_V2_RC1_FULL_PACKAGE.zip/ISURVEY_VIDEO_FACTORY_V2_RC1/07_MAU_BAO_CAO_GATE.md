# MẪU BÁO CÁO STOP/GO GATE — iSurvey Video Factory

**Phiên bản:** v2.0-RC1. Mẫu cần điều chỉnh nhẹ theo slice, nhưng không được bỏ các trường quyền và bằng chứng.

## A. Thông tin kiểm tra

| Trường | Giá trị |
|---|---|
| `TASK_ID` | [ghi ID task được duyệt] |
| `GATE` | [D1/I1/I2a/I2b/I3a/I3b/I4a/I4b/I5 hoặc mã khác được duyệt] |
| `APPROVAL_SCOPE` | [chỉ rõ văn bản/lệnh của owner; không có thì BLOCKED] |
| `WORKSPACE` | `D:\AIProject\isurvey` hoặc path thực đã kiểm tra |
| `REPO_SHA_BEFORE/AFTER` | [mã SHA thật; không giả] |
| `HOST/BUNDLE/CAD` | [mã/phiên bản/chưa kiểm tra] |
| `ALLOWLIST/FORBIDDEN_PATHS` | [liệt kê] |
| `START/END/DEADLINE` | [mốc thời gian thực hoặc NOT_TESTED] |

## B. Kết quả thực tế

| Hạng mục | Đã thực hiện | Chứng cứ và đường dẫn | Kết luận |
|---|---|---|---|
| [Mục 1] | [hành động] | [path:line/log/hash] | PASS/FAIL/NOT_TESTED/INSUFFICIENT_EVIDENCE |
| [Mục 2] | [hành động] | [path:line/log/hash] | PASS/FAIL/NOT_TESTED/INSUFFICIENT_EVIDENCE |

## C. Kiểm tra phạm vi và an toàn

- **Mã C# nghiệp vụ có bị thay đổi?** [KHÔNG / CÓ + chi tiết / CHƯA ĐỦ CHỨNG CỨ]
- **CAD, dữ liệu công trình thật hoặc MASTER đã bị tác động?** [...]
- **Windows bảo mật/driver/phiên tài khoản có bị thay đổi?** [...]
- **Drive/YouTube/TTS API có được gọi không?** [...]
- **Chi phí thực tế phát sinh?** [...]
- **Git diff và tệp mới:** [...]
- **Backup/rollback và điểm khôi phục:** [...]
- **Những bài test chưa thực hiện:** [...]

## D. Danh mục blocker

| Mức | Điều kiện chưa đạt | Ảnh hưởng và phạm vi | Cần người quyết định |
|---|---|---|---|
| P0 | [mô tả cụ thể] | [chức năng/job nào bị chặn] | [chủ dự án/kỹ sư] |
| P1 | [mô tả cụ thể] | [...] | [...] |

## E. Quyết định STOP/GO đề nghị

**Đề xuất:** `STOP` hoặc `GO` cho **slice tiếp theo cụ thể**, kèm bằng chứng. Đây **chỉ là đề xuất của team**, không thay thế hành động phê duyệt của Chủ dự án.

### Điều kiện để Chủ dự án quyết định

1. Những điểm đã PASS có bằng chứng gì?
2. Điểm nào chưa đủ chứng cứ nhưng có thể để dành per-feature, không chặn toàn hệ thống?
3. Có side-effect, rủi ro nguồn/công trình thật, quyền đăng, trễ bàn giao, chi phí hay không?
4. Hành động được xin phép tiếp theo chính xác là gì (file, tool, thời gian, quyền, test, rollback)?

**ĐỀ NGHỊ CHỦ DỰ ÁN:** [một quyết định cụ thể, không gom nhiều quyền khác loại vào một ô ký].
