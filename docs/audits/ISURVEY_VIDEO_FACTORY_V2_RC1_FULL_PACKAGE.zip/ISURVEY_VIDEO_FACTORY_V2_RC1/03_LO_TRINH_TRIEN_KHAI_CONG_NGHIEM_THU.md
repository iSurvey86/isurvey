# LỘ TRÌNH TRIỂN KHAI & CỔNG NGHIỆM THU — iSurvey Video Factory

**Phiên bản:** v2.0-RC1 · 10/11/2026  
**Tính chất:** Đề xuất thực thi KT-01..KT-07, KT-09. Cổng và tiêu chí chi tiết chỉ có hiệu lực khi Chủ dự án chấp thuận; không tự trao quyền vận hành.

## 0. Trạng thái đường cơ sở và quyền

- `Phase 01` kiểm toán mã nguồn tĩnh đã được **đóng có điều kiện** và cho phép chuyển sang **thiết kế** Prompt Master.
- Source USER baseline = 52 hồ sơ, 10 `SOURCE_SUPPORTED`, 42 `PARTIAL_BLOCKED`, 52 runtime `NOT_TESTED`.
- `D0`: Chủ dự án duyệt bộ tài liệu này (chưa xác nhận trong lúc tạo).
- `D1`: cho phép Cursor đọc-only và **nộp kế hoạch**. Chưa cho phép code/CAD/cloud.
- `I1, I2, I3, I4, I5`: chỉ khởi động sau khi có phê duyệt riêng kèm danh sách file/side effects được cho phép.

## 1. Sơ đồ công việc và kết quả

| Chặng | Mục tiêu | Đầu ra nghiệm thu | Khóa cứng |
|---|---|---|---|
| D0 | Thông qua rule/master | Phiên bản ký duyệt, SHA256, ranh giới quyền | Không tự cài vào repo |
| D1 | Khảo sát read-only + thiết kế khả thi | Repo SHA, bản đồ module, 3 lựa chọn kỹ thuật có căn cứ, risk register, chọn slice I1, file allowlist | **Không sửa/ghi repo** |
| I1 | Core không phụ thuộc GUI/cloud | Typed contracts, versioned feature registry, state/event log/checkpoints, unit tests, mẫu QA | Chỉ thêm/chỉnh file video factory trong allowlist; không sửa C# nghiệp vụ |
| I2a | Fixture và expected independent | MASTER/WORK/REFERENCE registry, generator/mẫu native khi có phép, kiểm tra integrity | Không chạy CAD chưa được phép |
| I2b | CAD preflight/runner & monitor-off proof | Matched plugin/build/source, CAD result assertions, capture thử thật 4K monitor off, evidence | Chỉ data synthetic; phiên Windows hợp lệ |
| I3a | Storyboard, capture, narrator, composer | 1 video có chứng cứ CAD thật, 4K master, preview1080, SRT/VTT, QA | Feature verified; không ảnh giả |
| I3b | Hai video trial + giọng | 2 video hoàn chỉnh đạt G4, hồ sơ voice profile cho Owner | Không duyệt lời thoại từng video; owner duyệt profile sau 2 trial |
| I4a | Scheduler, protection, restore | Bàn giao máy theo giờ biến thiên, dừng an toàn, backup/restore drills | Không late handback, không replay CAD unknown |
| I4b | Review G5, Drive, YouTube | Local review, Drive one way, approval checks, private-first, upload reconcile | Không G5 tự động; quyền upload/publication tách |
| I5 | Nghiệm thu NT-01–NT-15 qua 6 cấp | Bằng chứng PASS/FAIL/NOT_TESTED, test ca đêm, sự cố, nhiều ca | Không tự mở production |

**Giải trình:** Bảng là đề xuất sequencing, không cam kết những công cụ đã có hoặc thời lượng triển khai. Nên ưu tiên thử monitor-off ngay sau khi có Runner tối thiểu để phát hiện blocker sớm.

## 2. Gate chi tiết: Đọc-only thiết kế D1

**Được phép:** `git status --short`, `git rev-parse HEAD`, đọc `.sln`, `.csproj`, `.cursor/`, `tools/video`, plugin references, docs/audits, kiểm tra quyền/lệnh bằng cách đọc file; không đọc/lộ secrets. Nếu cần chạy lệnh metadata `git`, chỉ chạy khi được user cho phép trong lệnh D1 và không làm thay đổi working tree.

**Không được phép:** build, unit tests nếu có side effects chưa được phân tích, launch CAD/Civil 3D, pip/npm install, copy rule, tạo branch, `git checkout`, `git add/commit`, Windows config, API call, đăng nhập dịch vụ hoặc viết file trên repo.

**Đầu ra tối thiểu (có thể đặt ngoài repo hoặc đưa trong chat):**
1. `D1_REPO_INTEGRATION_MAP` — đường dẫn thực tế, baseline SHA, hiện trạng các tools video cũ, điểm tích hợp an toàn, zone không được sửa.
2. `D1_ARCHITECTURE_DECISIONS` — lựa chọn ngôn ngữ/bibliography/durable state/video engine/capture, 2–3 lựa chọn và lý do, rủi ro cần test.
3. `D1_IMPLEMENTATION_SLICES` — allowlist cho I1, test plan, rollback, input thiếu và effort tương đối có căn cứ.
4. `D1_RISK_STOP_GATE` — danh mục blockers, OWNER DECISION REQUEST. Không chọn pilot hoặc tự viết code.

**D1 PASS** khi Chủ dự án chấp thuận một plan có đủ baseline, module boundary, file allowlist, rollback và tiêu chí test. Cursor báo PASS theo khả năng tự thẩm tra không thay thế phê duyệt.

## 3. Gate kiểm chứng chức năng ngay trước quay

| Bước | Điều kiện bắt buộc | Bằng chứng |
|---|---|---|
| F0 | Feature nằm trong inventory định danh đúng BF, no source overclaim | Feature registry, SHA, evidence refs |
| F1 | Đọc source đầy đủ đến hậu điều kiện cho claim của video | `path:line`, service/handler chain, branches |
| F2 | iSurvey actual bundle/build/version khớp và CAD license hoạt động | Preflight machine snapshot, assembly/plugin ID |
| F3 | Synthetic fixture `MASTER`/`WORK COPY` + independent expected | file hash, spec, reference, tolerance |
| F4 | CAD dry-run trên WORK COPY, quan sát kết quả độc lập, cleanup | log, screenshot/video, checks, CAD objects/file |
| F5 | GUI runner ổn định, không replay ambiguous mutation | event journal, timeout handling |
| F6 | Ca/màn hình/Sleep/security/budget đáp ứng bối cảnh thực tế | session record, 4K monitor-off evidence nếu là ca đêm |
| F7 | Có sự cho phép riêng đối với test/production này | task ticket, scope, date, owner |

**F0–F7 tất cả đạt** mới cho phép `READY_TO_CAPTURE` trong đúng version/môi trường/fixture. F1 chưa rõ với `PARTIAL_BLOCKED` thì dừng feature đó, không dừng thiết kế toàn hệ thống. Không suy từ 10 `SOURCE_SUPPORTED` thành F1–F7 đã đạt.

## 4. Bản đồ QA G1–G4 (đề xuất phân rã kỹ thuật)

**Bản chất G4 đã chốt:** G4 PASS tức `PRODUCTION_COMPLETE`, độc lập G5/Drive/upload. **Chi tiết chia G1–G3 sau đây là đề xuất cho D1 xác nhận**, không phải nhãn từ báo cáo cũ A/B/C.

| Gate | Đề xuất kiểm tra chính | Blocking evidence |
|---|---|---|
| G1 | Source/runtime/fixture đúng version, command/action thực, independent CAD result | source and run refs, checksums, assertion logs |
| G2 | Kịch bản kỹ thuật nhất quán với CAD, đầy đủ bước và lời bình, không sai tọa độ/cao độ | storyboard manifest, reference outcomes |
| G3 | Capture real 4K, audio nam Bắc, phụ đề đồng bộ, privacy/brand/rights | media QC, captions, voice glossary, footage markers |
| G4 | Master 3840x2160, preview1080, SRT/VTT, metadata, manifests/checksums, QA các check mandatory PASS | immutable local package, checksum list, QA G4 report |

- `G4 PASS` nghĩa local production complete; Drive copy có thể PENDING và G5 có thể PENDING.
- Sau thay đổi voice, clip hoặc master cần recompute checksum và invalidation các gates/approval bị ảnh hưởng.
- Chỉ owner duyệt G5 đúng video/version/checksum; UploadAuth & PublishAuth là các sự kiện riêng.

## 5. NT-01..NT-15 — ma trận nghiệm thu 6 cấp (KT-09.6 đã chốt)

| Mã | Phạm vi | Test bắt buộc | Kết quả cần lưu |
|---|---|---|---|
| NT-01 | Source/build/plugin | Verify C# SHA & actual loaded assembly + installed iSurvey bundle | version manifest + load evidence |
| NT-02 | Fixture | Synthetic fixture + immutable master + independent baseline | hashes/measurements/tolerance |
| NT-03 | CAD automation | Gửi lệnh, quan sát hoàn tất/đúng object, lỗi bất thường, rollback | action/event/assertions |
| NT-04 | 4K monitor physical off | Dell P3225QE tắt bằng nút nguồn; video vẫn quay đúng 4K thật hoặc FAIL | screen-off procedure, raw recording metadata |
| NT-05 | Windows session/Sleep | interactive session, lock/unlock/restart, policy compliant, Sleep suppressed in authorized shift | event log & video/result |
| NT-06 | TTS/subtitles | Nam miền Bắc, phát âm thuật ngữ/số liệu và đồng bộ | accepted voice samples + SRT/VTT QC |
| NT-07 | Outputs | Master 4K, preview1080, codec/fps/quality measured | ffprobe/media info, playback |
| NT-08 | G1–G4 gate safety | FAIL/UNKNOWN cannot skip mandatory gate | state transition tests, QA reports |
| NT-09 | Shift handback | deadline configurable, dynamic margins, early handover & safe stop | timestamps, operator handback evidence |
| NT-10 | Drive copy | Completed local package only, one-way, checksum, network interruptions | cloud IDs vs local hashes |
| NT-11 | Crash/recovery | AutoCAD hang, encoder failure, outage, ambiguous CAD action, restore | journal, restore drills, idempotency proof |
| NT-12 | Budget/storage | thresholds evidence-based, full disk, API quota, no unwanted delete/buy | stop behavior + usage report |
| NT-13 | G5 per version | owner approval exact version/checksum; changed artifact invalidates | approval ledger tests |
| NT-14 | YouTube rights | upload only with UploadAuth, publish only PublishAuth, reconcile ambiguous upload | audit events, remote ID, privacy |
| NT-15 | Repeated overnight runs | multiple sessions stable and don't affect engineer work | series logs & QA evidence |

**Kết quả chuẩn:** `PASS | FAIL | NOT_TESTED | INSUFFICIENT_EVIDENCE`; `NOT_APPLICABLE` chỉ khi có chứng cứ đúng lý do. Không đổi NOT_TESTED thành PASS bằng suy luận.

## 6. Điều kiện chặn theo cấp nghiệm thu

| Cấp | Điều kiện dừng |
|---|---|
| 1 — Bộ phận | Unit contracts/integrity/security test chưa đạt |
| 2 — Một video thật | Chưa có feature runtime verified, không có 4K thật, thiếu baseline |
| 3 — Hai trial | Chưa đủ hai video kỹ thuật hoàn chỉnh hoặc Owner chưa duyệt voice profile |
| 4 — Ca không giám sát | Màn hình tắt làm mất 4K/interactive session/không bàn giao đúng giờ |
| 5 — Phục hồi | Replay CAD mơ hồ, không restore được trạng thái/mất dữ liệu |
| 6 — Nhiều ca | Lỗi kéo dài, tác động lên ca kỹ sư hoặc thiếu bằng chứng ổn định |

## 7. Đầu ra công việc ở mỗi slice — kiểm soát thực hiện

- `ARTIFACT_MANIFEST` chứa version, SHA256, source identifiers, host/tool identities, known unknowns.
- `CHANGELOG` chỉ kể thay đổi được chứng minh; không tự gắn PASS.
- `TEST_REPORT` cho từng test, điều kiện, input, output, thời điểm, path và bằng chứng.
- `GATE_REPORT` nêu STOP/GO đề xuất và danh sách việc chờ chủ dự án.
- `ROLLBACK_PLAN` có checkpoint và những hành động không thể replay.
- `SECURITY_REVIEW` không chứa keys/OTP; host identity chỉ đủ phục vụ audit, tránh tiết lộ thông tin định danh ngoài phạm vi.

**Lưu ý cuối:** D1/triển khai không phải quyền khởi động máy hay cloud mặc định. `GO` phải là quyết định của Chủ dự án theo ticket, không phải trạng thái do Cursor tự viết.
