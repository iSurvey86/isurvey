# BỘ QUY TẮC BẮT BUỘC — iSurvey Video Factory

**Phiên bản:** v2.0-RC1 — 10/11/2026  
**Trạng thái:** Bản trình duyệt; khi được Chủ dự án phê duyệt nội dung thì dùng làm chuẩn chỉ đạo triển khai.  
**Áp dụng:** phần mềm/hạ tầng Video Factory và tất cả Agent, script, công cụ hỗ trợ, nhân sự liên quan.  
**Không sửa:** nghiệp vụ C# của iSurvey, trừ khi Chủ dự án khởi tạo nhiệm vụ phát triển iSurvey **riêng**, ngoài Video Factory.

## Q01. Quyền hạn và ranh giới nhiệm vụ

1. **Khác biệt bắt buộc:** (i) phê duyệt kiến trúc, (ii) duyệt tài liệu triển khai, (iii) cho phép thay đổi repo, (iv) cho phép kiểm thử máy/CAD, (v) nghiệm thu runtime, (vi) duyệt giọng, (vii) G5 cho từng video, (viii) cho phép tải YouTube, (ix) cho phép công khai. Không suy luận quyền này từ quyền kia.
2. Cursor là công cụ thực thi có kiểm soát. Mỗi phiên làm việc phải có `TASK_ID`, phạm vi file, danh sách tác vụ được phép, hành vi bị cấm, tiêu chí PASS, STOP gate và Chủ dự án ra quyết định.
3. Không tự commit, push, deploy, tạo API key, truy cập tài khoản cloud, mua gói dịch vụ, thay đổi bảo mật Windows, cài driver, thay đổi nội dung công trình thật hoặc bật AutoCAD ngoài phạm vi được cấp quyền.
4. Thiếu đầu vào, quyền hoặc bằng chứng quan trọng: ghi `BLOCKED`/`NOT_TESTED`, báo quyết định cần được đưa ra, STOP tác vụ liên quan. Không bịa kết quả, không tự hạ điều kiện.
5. Chủ dự án duyệt lịch, giới hạn chi phí, bảo mật, hồ sơ giọng, G5, upload, publication, thay đổi lớn. Kỹ sư sử dụng máy có quyền yêu cầu trả máy/nhận lại sớm. Bộ điều phối chỉ tự động trong các quyền đã được cấp.
6. Thời điểm hiện tại **CHỈ DUYỆT SOẠN bộ tài liệu**. Prompt khởi động phải thực hiện **PLAN ONLY / READ ONLY** tới khi có phê duyệt giai đoạn khác.

## Q02. Thẩm quyền nguồn và chứng cứ

1. Nguồn sự thật của chức năng: C# ở **commit được ghi nhận** → build/release thực tế → plugin iSurvey **đang được AutoCAD nạp** → tương tác và kết quả AutoCAD thật → đối chứng độc lập. Tên lệnh trong Excel hoặc báo cáo cũ không tự chứng minh hành vi.
2. Phase 01 đã đóng **có điều kiện**: 52 hồ sơ USER gồm 10 `SOURCE_SUPPORTED`, 42 `PARTIAL_BLOCKED`; tất cả `NOT_TESTED` runtime. Không biến 52 thành số video cần quay hoặc suy ra kiểm kê tuyệt đối tất cả người dùng nếu thiếu kiểm chứng đường UI động.
3. Tính năng có thể có alias hoặc nhiều nút UI; một tính năng có thể thuộc nhiều bài học, một bài học có thể dạy nhiều tính năng; **không** bắt buộc một lệnh = một video.
4. Registry định danh: mã `BF-*` hiện tại chỉ là định danh catalog baseline, phải có ID ổn định/migration khi đổi tên/gộp/tách. Không dùng số dòng, tên tệp hay `AUD-xxx` làm khóa vĩnh viễn.
5. Mọi khẳng định kỹ thuật quan trọng phải ghi `repo_sha + path:line + method/handler`, đánh dấu rõ phần chứng minh được và phần còn chưa chứng minh. Khi không thể kiểm tra source vì bảo mật, cung cấp kiểm tra tại chỗ thay vì sao chép bí mật ra ngoài.
6. Lỗi iSurvey phải lập issue có bước tái hiện, không sửa/ngụy tạo nghiệp vụ để quay video.

## Q03. Cổng chứng minh riêng cho từng tính năng

1. `SOURCE_SUPPORTED` chỉ là bằng chứng mã nguồn tĩnh trong phạm vi đã xem; `PARTIAL_BLOCKED` chặn cả plan hành động và hàng đợi quay tự động nếu chưa được mở cổng. `STUB/EXCLUDED` không làm video chức năng đã hoàn thiện. Hành vi `NOT_TESTED` không được gọi là runtime verified.
2. Cần **PER_FEATURE_VERIFICATION** trước quay: (a) chứng cứ source phù hợp; (b) repo/build/installed plugin/version khớp; (c) quyền CAD/giấy phép; (d) dữ liệu mẫu & expected baseline; (e) dry-run CAD thật trên WORK COPY; (f) kiểm chứng hậu điều kiện độc lập; (g) xác nhận cleanup/rollback; (h) quyền và thời gian ca hợp lệ.
3. Với chức năng xóa/ghi đè, cần đánh giá side effects, tình huống crash, tính idempotent trước khi duyệt. Kết quả mơ hồ => **không tự replay**.
4. Các ca cần bảo vệ đặc biệt: `ISURVEY_DGN_TO_CAD` (nhập và hậu xử lý không đồng bộ), `ISURVEY_CAD_TO_DGN` (ghi đè/Xóa tệp cũ và chất lượng DGN), `VEMCD` (xóa handles cũ trước khi dựng lại), `TRACAOD` (tạo/xóa DBText tạm), `ISURVEY_LOGOUT` (trạng thái phép/online bất đồng bộ), `ISURVEY_MAP_SAT` (pipeline tile ghép/lưu chưa đầy đủ).
5. Dù hoàn thành gate cho một tính năng, các tính năng còn lại vẫn giữ nguyên trạng thái chặn; không mở khóa hàng loạt bằng suy luận từ một pilot.

## Q04. Fixture — dữ liệu mẫu — đối chứng

1. Fixture là **synthetic** hoặc dữ liệu hợp pháp đã được phép; không lấy bản vẽ công trình thực để quay. `MASTER` bất biến có version/hash; `WORK COPY` mới cho mỗi lần thử/cảnh; `REFERENCE/EXPECTED` phải độc lập với iSurvey được kiểm thử.
2. Dữ liệu có seed, đơn vị và hệ tọa độ (có thể giả định nhưng phải ghi), độ cao/tọa độ/kích thước, định dạng, nội dung mong đợi, dung sai đã có căn cứ; có kiểm tra tính hợp lệ.
3. Không giả mạo DGN bằng đổi đuôi DXF/DWG; đối tượng Civil 3D native phải thực sự là đối tượng đúng loại, không thay bằng polyline/text để chứng minh một chức năng đòi Surface/Alignment.
4. Mỗi take reset từ WORK COPY mới; nếu thao tác nghi có hiệu ứng chưa rõ, cô lập và báo trạng thái; không dùng file đã bị sửa để làm master cho take kế tiếp.
5. Khi cho phép người xem tải fixture, tách gói công khai khỏi dữ liệu nội bộ; xác minh quyền, không nhúng bí mật hoặc đường dẫn nội bộ.

## Q05. AutoCAD runner và bằng chứng thật

1. Dùng API/command/UI/keyboard/mouse theo độ ổn định và quyền của môi trường, không mặc định click tọa độ màn hình là cách duy nhất; mỗi action có tiền điều kiện, thời hạn, quan sát hoàn thành, hậu điều kiện, ảnh/video/log bằng chứng.
2. `SendStringToExecute`/nhập lệnh chỉ chứng minh đã **gửi yêu cầu**, không chứng minh lệnh đã hoàn thành. Phải xét vòng đời document, command, dialog, async, modeless palette, transaction và lỗi.
3. Thao tác CAD phải được ghi hình thật. Không dùng ảnh giả, AI-generated UI, dựng lại hộp thoại hay thay số liệu trên màn hình cho có vẻ đúng.
4. Không đè lên số liệu/đối tượng CAD bằng watermark, callout hoặc hiệu ứng chỉnh sửa; hậu kỳ có thể cắt chờ, phóng vùng, highlight nếu không làm sai bằng chứng.
5. Windows App Control, UAC, khóa máy, trạng thái logged-in và CAD automation phải tuân chính sách bảo mật; không tự đăng nhập lại hoặc vượt lock screen. Tách **supervisor** và **GUI runner**. Nếu không có phiên GUI hợp lệ, chỉ các công việc không tương tác được phép chạy.
6. Hạn chế về DPI (user 200%, system 150%), màn hình Dell P3225QE DP, âm thanh và driver phải được thử trên máy. Không giả định màn hình vật lý tắt vẫn có 4K.

## Q06. Video, âm thanh, thương hiệu

1. Master 4K **3840×2160 16:9** và preview 1080p độc lập; đo/đọc metadata và xem mẫu để kiểm chứng không phải upscale trá hình. Frame rate/codec dùng cấu hình đã đo và được duyệt, không cố định 60 fps bằng suy đoán.
2. TTS **nam tiếng Việt miền Bắc**, bảng phát âm thuật ngữ khảo sát/điện lực/tọa độ/cao độ/đơn vị; SRT và VTT khi yêu cầu, đồng bộ thời gian từ audio thực. Kiểm tra giấy phép và quyền API thương mại; đăng ký dịch vụ web/Plus không mặc định có API usage.
3. **Không yêu cầu duyệt từng kịch bản/từng câu thoại.** Sản xuất **hai video thử hoàn chỉnh và đạt G4** với nội dung thực tế, rồi Chủ dự án duyệt **hồ sơ giọng đọc** trước khi sản xuất hàng loạt; sửa giọng phải quản lý phiên bản.
4. Thời lượng tham chiếu: Feature 3–5 phút; Workflow 5–8 phút, có ngoại lệ vì nội dung thực tế. Các lớp Feature/Workflow/Update/Troubleshooting/Tips; ưu tiên nội dung dạy kỹ thuật đúng hơn SEO/quảng cáo.
5. Dùng logo/bộ nhận diện iSurvey **đúng phiên bản được duyệt**; kiểm tra SVG/vector gốc, nền sáng/tối, typography. Không sử dụng file không chứng minh được nguồn/quyền. Không tự gắn số version iSurvey dựa trên tên tệp.
6. Kịch bản và manifest phải truy vết đúng từng cảnh, câu bình, hành động, kết quả, nguồn; không tự bịa lời hứa/đo lường kỹ thuật.

## Q07. Trạng thái độc lập — kiểm định — phê duyệt

1. Ít nhất các trục độc lập: `PRODUCTION`, `QA_G1_G4`, `G5`, `DRIVE_COPY`, `YOUTUBE_UPLOAD`, `PUBLICATION`. Không gộp tất cả thành một status hoặc tự suy status sau từ status trước.
2. `G4 PASS` = `PRODUCTION_COMPLETE` (gói master/preview/subtitle/manifest/QA đã **hoàn thành tại SSD cục bộ**) **không phụ thuộc** G5, Drive hay YouTube.
3. G5 là **Chủ dự án phê duyệt đúng `video_version + artifact_checksum`**; thay phiên bản/cảnh/giọng/master phải xét lại hiệu lực phê duyệt. Nhiều video G4 có thể nằm hàng đợi chờ G5 độc lập.
4. G5 **không cấp phép upload**. `UPLOAD_AUTHORIZATION` và `PUBLICATION_AUTHORIZATION` là hai quyền riêng, có dấu người duyệt và scope. Mặc định YouTube private-first khi có quyền upload; không tự publish.
5. Không tự xóa video cũ hoặc thay thế không ghi version. Mọi QA kiểm định phải có `PASS | FAIL | NOT_TESTED | INSUFFICIENT_EVIDENCE`; tiêu chí bắt buộc không được bỏ qua. `NA` chỉ khi có căn cứ không áp dụng.
6. Cổng QA được phê duyệt theo G1..G4; ánh xạ kỹ thuật chi tiết trong tài liệu 03 là **đề xuất để thẩm định khi triển khai**, không được ghi ngược thành quyết định lịch sử nếu chưa xác nhận.

## Q08. Local SSD là nguồn chính; Drive chỉ một chiều

1. SSD cục bộ là bản gốc vận hành của: nguồn tạo video, fixture working, footage, trạng thái, QA, thành phẩm và manifest. Nên có staging/checksum/atomic finalize để phát hiện tệp dở dang.
2. Google Drive **CHỈ NHẬN BẢN SAO** gói video đã `G4 PASS` (trừ khi Chủ dự án ban hành chính sách khác rõ ràng); không dùng làm workspace đang dựng, không đồng bộ hai chiều, không tự xóa bản cục bộ khi copy thành công.
3. Trạng thái copy phải kiểm tra được checksum, có retry an toàn; upload mơ hồ cần reconcile trước khi retry tránh nhân bản. Drive chưa copy không được kéo ngược `G4 PASS` về chưa hoàn thành.
4. Backup độc lập với Drive. D/E là ổ nội bộ tại cùng máy cho tới khi chứng minh phân tách vật lý; cần kế hoạch bản sao ngoài máy hoặc ngoài sự cố chung, RPO/RTO được thẩm định dựa dữ liệu thực.
5. G/H định dạng FAT32 không chọn làm mặc định chứa master hoặc footage lớn (giới hạn tệp FAT32). Không tự dịch chuyển, định dạng hoặc xóa các ổ này.

## Q09. Điều phối ca và bàn giao Windows

1. Chủ dự án/kỹ sư bàn giao máy theo ca; lịch được cho phép rõ, giờ trả máy là **biến cấu hình**, 08:30 chỉ ví dụ, không hardcode.
2. **Chỉ một video job sản xuất hoạt động đồng thời.** Các giai đoạn có tiêu thụ lớn **TUẦN TỰ**: sản xuất → sao chép Drive nếu có thời gian → chuẩn bị trả máy. Không mặc định vừa render vừa copy Drive.
3. Scheduler tính lại thời gian khả dụng, throughput, thời gian dừng an toàn, dự phòng và giờ bàn giao theo đo thực tế. Nếu không chắc dừng an toàn đúng hạn, **không khởi động job mới**; hàng đợi tiếp tục ca sau.
4. Sau bàn giao, người sử dụng **tắt màn hình Dell P3225QE bằng nút nguồn**. Điều này khác Sleep và Windows lock. **Bài thử quay AutoCAD native 4K khi màn hình vật lý tắt** là blocker trước sản xuất qua đêm. Không mua thiết bị giữ EDID hay thay driver khi chưa phê duyệt.
5. Chống Windows Sleep trong ca bằng biện pháp được phép và kiểm chứng; hoàn nguyên khi trả máy; Windows Update/restart có lịch. Không vô hiệu hóa bảo mật hay đăng nhập tự động không an toàn.
6. Kỹ sư yêu cầu bàn giao sớm => dừng ở điểm an toàn; không force-close CAD nếu dữ liệu chưa rõ; báo lý do nếu không thể bàn giao ngay lập tức an toàn.
7. Bảo vệ ca kỹ sư hơn số video được tạo. Đảm bảo giám sát tài nguyên SSD/CPU/GPU/network và khả năng dừng trước hạn.

## Q10. Sao lưu — lỗi — phục hồi

1. Checkpoint chỉ ghi `VALID` sau khi tệp/chứng cứ đã hoàn tất và xác minh; không checkpoint giả trong transaction CAD chưa biết kết quả.
2. Phục hồi theo phần có kết quả hợp lệ: source/fixture → verified CAD takes → audio/subtitle → render → final G4. Không replay lệnh CAD có side effects nếu trạng thái mơ hồ.
3. Mất điện, mất internet, CAD hung, render fail, full SSD, Windows reboot, Drive/YouTube partial upload đều phải có runbook/kiểm thử cô lập. UPS và BIOS auto-restart hiện là **UNKNOWN**; không giả định máy sẽ tự bật lại.
4. Sau sự cố phải kiểm tra phiên Windows tương tác, quyền ca, dung lượng, plugin đúng version, nguồn fixture/MASTER, thời gian còn lại và trạng thái tác vụ trước khi tiếp tục.
5. Nghiệm thu phục hồi bằng test restore thật. Không tự rút nguồn máy chứa dữ liệu quan trọng để chứng minh crash behavior.

## Q11. Bảo mật, quyền sử dụng, chi phí

1. Không đưa token, OTP, license secret, dự án nội bộ, thông tin cá nhân nhạy cảm vào video, log, LLM prompt hay report. Secret ở vault/OS store có quyền tối thiểu; mask tất cả báo cáo.
2. Không chạy `git push`, cloud upload hay kích hoạt quyền YouTube nếu chưa có nhiệm vụ được phép; chọn OAuth scope tối thiểu khả dụng, nhận diện người duyệt bằng workflow độc lập, không lẫn quyền token với quyền quyết định.
3. Kiểm soát chi phí TTS, rendering, API, Drive, YouTube quota, dung lượng; dự báo trước job; không tự mua/nâng cấp hoặc xóa file trọng yếu khi vượt giới hạn.
4. App Control for Business trên Windows đang ở trạng thái Enforced theo báo cáo trước; mọi executable cần tuân chính sách, không tự tắt chính sách.
5. Không coi 136GB `Display Memory` là VRAM; RTX 5090 có khoảng **32 GB dedicated**. Thông số phần cứng và tốc độ xử lý phải benchmark, không suy diễn tốc độ GPU/encoder.

## Q12. Nghiệm thu, báo cáo và chống nghiệm thu hình thức

1. Nghiệm thu sáu cấp: unit/module; một video thực; hai video trial + duyệt giọng; ca không giám sát/tắt monitor; sự cố/restore; ổn định nhiều ca.
2. Áp dụng ma trận NT-01..NT-15 (tài liệu 03) với bằng chứng file/log/checksum/runtime; các lỗi bảo mật, sai kỹ thuật, quyền xuất bản hoặc trễ bàn giao là blocker.
3. Mỗi vòng triển khai phải nêu: `what changed`, `why`, diff, impacted modules/features, test thực sự chạy, test chưa chạy, PASS/FAIL, STOP gate, rollback và việc cần Chủ dự án duyệt.
4. Không tự nâng tĩnh thành runtime; không cộng các nhãn phần trùng để tạo KPI; không lặp vòng kiểm toán rộng chỉ để báo cáo đẹp.
5. Khi hoàn thành từng slice, **DỪNG** trước việc tiếp theo có thay đổi trạng thái/cơ sở quyền khác. Khuyến nghị không đồng nghĩa phê duyệt.

---

## Điều kiện buộc STOP ngay

- Có nguy cơ thay đổi C# nghiệp vụ hoặc tài liệu/công trình MASTER.
- Thiếu quyền hoặc phiên Windows tương tác hợp lệ, chưa kiểm chứng màn hình tắt khi muốn quay không giám sát.
- Command/CAD mutation chưa rõ hậu quả, chờ đợi vô hạn, hành động replay mơ hồ.
- Thiếu mã nguồn/build/installed bundle khớp; fixture không có independent reference.
- QA bắt buộc FAIL/chưa đủ bằng chứng, video chưa có duyệt đúng phiên bản, upload/publication thiếu quyền.
- Ngân sách/ổ đĩa/giờ bàn giao không còn biên an toàn.
- Gặp yêu cầu hoặc tài liệu cũ trái quyết định KT-01..KT-09.

**Đầu ra của STOP:** giữ dữ liệu nguyên trạng, ghi trạng thái và bằng chứng, đưa ra phương án xử lý ngắn và quyết định cụ thể cần Chủ dự án.
