# THẨM ĐỊNH ĐỘC LẬP R02 — iSurvey Video Factory

**Ngày đánh giá:** 10/11/2026  
**Nguồn:** `2026-11-10_ISURVEY_VIDEO_FACTORY_SOURCE_AUDIT_R02.zip` (45 mục, ZIP kiểm tra giải nén đạt), đối chiếu gói R01 và yêu cầu kiểm toán R02 ngày 10/11/2026.  
**Phạm vi:** thẩm định tính nhất quán nội tại, bằng chứng và yêu cầu kiểm toán tĩnh; **không được cung cấp repo C# gốc**, nên không thể kiểm lại toàn bộ đường dẫn/dòng code trên máy D:\\AIProject\\isurvey.

## 1. Quyết định đề xuất

**TIẾP NHẬN R02 CÓ ĐIỀU KIỆN ở cấp kiểm kê cấu trúc; CHƯA NGHIỆM THU PHASE 01.**

R02 bổ sung đủ 12 nhóm tài liệu theo tên; phân biệt 125 khai báo `CommandMethod`, 46 alias trong `CommandAliases.cs`, 79 khai báo lệnh ở các tệp khác, 61 nút Ribbon (36 bật, 25 tắt), 91 `Click` XAML, 8 vị trí `PaletteCommands.Run`; 79 hồ sơ theo mã AUD và bảng Git trước/sau. Các số này tự khớp theo CSV. Toàn bộ 79 hồ sơ đều `runtime=NOT_TESTED`, phù hợp phạm vi kiểm toán tĩnh.

Tuy nhiên **79 KHÔNG phải số chức năng nghiệp vụ độc lập đã chứng minh**, mà do script lọc các khai báo không nằm trong `CommandAliases.cs` (xem `_tools/r02_extract.py`, `primary_cmds`/`primary_unique`). Số chức năng cần hướng dẫn và mẫu số bao phủ KT-05 còn mở.

## 2. Các phát hiện cụ thể

### P0-01 — Chuẩn hóa tính năng chưa đạt yêu cầu ngữ nghĩa

- Hai hồ sơ `AUD-037 ISURVEY_PROFILE_DRAW` và `AUD-038 VEMCD` đều ghi thin-wrapper sang `Draw` trong `src/Modules/Profile/ProfileModule.cs`.
- Hai hồ sơ `AUD-039 BANGCOC` và `AUD-045 ISURVEY_STATION_LIST` đều dẫn sang `ListStations` trong `src/Modules/Tuyen/RouteModule.cs`.
- `AUD-042 ISURVEY_ROUTE_NEW` / `AUD-050 TAOTUYEN` cùng dẫn sang `New`; `AUD-044 ISURVEY_ROUTE_STATIONS` / `AUD-048 PHATSINHCOC` cùng dẫn sang `Stations`.
- Cặp `AUD-058 ISURVEY_TERRAIN_BUILD` / `AUD-067 XAYMOHINH` cùng dẫn sang `Build` trong `TerrainModule.cs`.

Đây là những **ứng viên gộp**, cần đọc thân hàm và điều kiện thực thi để xác định chức năng cùng hay khác; không được khẳng định mọi cặp trùng 100% nghiệp vụ chỉ dựa trên tên hàm. R02 đang coi mỗi khai báo lệnh ngoài `CommandAliases.cs` là một canonical feature, không gộp những alias khai báo ngay trong module khác. Nhãn `canonical_features=79` vì thế chưa đủ căn cứ.

### P0-02 — 91 XAML event chưa truy vết đến nghiệp vụ

Tệp `_inventory_xaml_clicks.csv` có 91 dòng nhưng `03A_ANH_XA_LENH_ALIAS_RIBBON.csv` chỉ chứa 79 `PRIMARY_COMMAND`, 46 `ALIAS`, 36 `RIBBON_BTN`, 25 `RIBBON_PLACEHOLDER` (=186 dòng), **không có hạng mục `XAML_EVENT` hoặc `PALETTE_RUN` trong ma trận chính**. Các cột palette trong danh mục 03 chỉ phản ánh một số vị trí gọi lệnh, không phải toàn bộ tuyến điều khiển UI. Cần ánh xạ từng sự kiện tới handler, service, feature hoặc lý do loại trừ, có file:line; không ép mọi nút hủy/đóng dialog thành tính năng riêng.

### P0-03 — Phân tích hành vi mới ở mức cửa vào, chưa đến luồng dịch vụ

Hồ sơ 04 có đủ 79 mục riêng (tiến bộ rõ so với R01), nhưng nhiều mục chứa thông tin chung: `CommandMethod + handler method found in source`, chỉ nêu **tên kiểu service**, `catch` type, không chỉ rõ nhánh và hành vi, không xác nhận đối tượng CAD, kiểu dữ liệu, file/network IO, hậu điều kiện hoặc cách đo độc lập.

Ví dụ `AUD-013 NHAPDIEM`: chỉ nêu `ImportPointsWindow`, `PointDrawService`, `EnsureAuthenticated`; chưa xác định được định dạng tệp nhập, quy tắc tọa độ/cao độ, kiểu thực thể tạo, sai số và nhánh lỗi trong service. `AUD-012 D2C` tương tự chưa đọc đầy đủ `DgnImportService`/`DgnBatchService`. Đây là thông tin quan trọng để chuẩn bị video đúng kỹ thuật.

Cấp `SOURCE_BEHAVIOR_REVIEWED` được tự động gán bởi `_tools/r02_generate_reports.py` khi thân hàm đủ dài và có khớp từ khóa/kiểu; **không phải bằng chứng đã đọc và xác minh ngữ nghĩa sâu**. Số `70 SOURCE_BEHAVIOR_REVIEWED` vì thế phải hiểu thận trọng. Kiểm chứng 17/17 `VERIFIED_OPEN` chỉ kiểm tra có tên lệnh/method/chuỗi mong đợi trong tệp, không đối chứng độc lập luồng nghiệp vụ.

### P1-01 — Phân nhóm tự động sai, ảnh hưởng danh mục

Script `group_of` dùng so khớp chuỗi con và chọn nhóm đầu tiên. Trong CSV:
- `ISURVEY_UPDATE_GE` xếp `AUTH` dù tác vụ là cập nhật ảnh bản đồ;
- `DAODAUTUYEN` xếp `UAV` dù là đảo đầu tuyến;
- `ISURVEY_STATION_ADD_ONE` xếp `UAV` dù là nghiệp vụ cọc/tuyến;
- `ISURVEY_TERRAIN_ADD` xếp `UAV` dù là thêm điểm vào mô hình địa hình.

Phải đối chiếu module/handler, dữ liệu và kết quả rồi phân loại nghiệp vụ chính thức; không sửa bằng cách đổi thứ tự chuỗi con tùy ý.

### P1-02 — Mốc mã nguồn R01 và R02 khác nhau

- R01: `main`, HEAD `53c5eb4644f2dbc0f736e03098c749197a81a93e`.
- R02: `main`, HEAD `3a16cb3959dc4e65c08f77b6de26669b309739cd`.
- Trước/sau *trong chính đợt R02*, HEAD không đổi và `git diff --name-only` đều ghi xóa `docs/audits/2026-11-10_ISURVEY_VIDEO_FACTORY_SOURCE_AUDIT.zip` đã có từ trước. Báo cáo có căn cứ về việc không sửa tracked `src/` trong R02, nhưng chưa có bảng `git diff 53c5..3a16` giải thích thay đổi giữa hai đợt, gồm tệp source, command, UI có bị ảnh hưởng không.

Phải xác nhận R01 và R02 cùng một tập tính năng ở mốc nào, nếu nguồn thay đổi thì cần đánh dấu bản ghi R01 bị ảnh hưởng. Không tự checkout, reset hoặc điều chỉnh Git.

### P1-03 — Phân loại `IMPLEMENTED` và ứng viên quay có thể gây hiểu nhầm

R02 báo 71 `IMPLEMENTED`, 8 `STUB`, 25 Ribbon placeholder, 67 `video_candidate=YES`. Script quy định `IMPLEMENTED` khi tìm được method, **không chứng minh tính năng đã chạy**. Toàn bộ runtime vẫn `NOT_TESTED`. Cần đổi nhãn ý nghĩa thành `SOURCE_PRESENT/LIKELY_IMPLEMENTED` hoặc ghi rõ phân biệt `source status`/`runtime status`, rà soát các stub theo thân code. 67 là ứng viên tham khảo, không phải video đã sẵn sàng sản xuất.

### P1-04 — Bằng chứng chưa độc lập với chương trình sinh báo cáo

Trong ZIP có `r02_extract.py` và `r02_generate_reports.py` (tốt cho khả năng truy xuất), nhưng phép kiểm lại chỉ chạy trên cùng dữ liệu/do cùng logic tạo; thiếu kiểm tra thủ công và bảng luồng thực tế độc lập cho một mẫu đủ sâu. Nên bổ sung các bản trích đoạn chứng cứ ngắn có đường dẫn/dòng liên tục và có dấu kết luận riêng; không cần đưa cả nguồn C# nhạy cảm vào tài liệu.

## 3. Những nội dung R02 đã đạt

1. ZIP hợp lệ, đủ 12 nhóm đầu ra theo cấu trúc yêu cầu; hồ sơ 04 có 79 mục; các CSV đọc được UTF-8, không trùng `feature_id` ở 03.
2. Đếm lệnh và Ribbon nhất quán trong các tệp R02; 46 alias thuộc `CommandAliases.cs` đã có đường liên kết trong CSV; stub và Ribbon placeholder được tách riêng.
3. Đã bổ sung khảo sát UI XAML và Palette, mặc dù ánh xạ chưa đầy đủ.
4. Có Git before/after; báo cáo công khai giới hạn chưa đọc sâu dịch vụ; không tự tuyên bố Phase 01 hoặc runtime đã đạt.
5. Mở rộng danh sách đề xuất pilot, có phương án `NHAPDIEM/XUATDIEM` dễ chuẩn bị mẫu hơn DGN, tuy điểm số vẫn là đánh giá tĩnh.

## 4. Điều kiện để xem xét nghiệm thu Phase 01

- Danh mục `FEATURE` được chuẩn hóa theo **hành vi nghiệp vụ**, có bảng gộp/tách cho mọi lệnh bao gồm wrapper/alias nằm ngoài `CommandAliases.cs`, và bảng nối từ mã R01/R02.
- Có đường truy vết từng điểm vào: 125 command, 61 ribbon, 91 XAML Click và 8 Palette call (khi có trùng thì giải thích), các điểm đăng ký động/menu/context menu ghi phạm vi tìm và giới hạn.
- Cho mỗi feature thuộc phạm vi cần hướng dẫn: handler → service → điều kiện nhập → đầu ra / đối tượng CAD / I/O → nhánh lỗi / hậu điều kiện, bằng chứng `file:line` cụ thể và những gì chưa xác minh.
- Rà soát lại phân loại USER/ADMIN/INTERNAL/STUB/placeholder; không coi `CommandMethod` là bằng chứng thực thi thành công.
- Có bản đối chiếu R01 commit → R02 commit, và xác minh không sửa nguồn trong đợt bổ sung.
- Bảng tự kiểm bằng chứng độc lập đủ kiểm tra, không chỉ `has_cmd / has_method / has_expect`.
- Runtime vẫn `NOT_TESTED`: kiểm toán tĩnh đạt (nếu sau đó đủ) **không đồng nghĩa** test CAD/G1–G5 đã đạt.

## 5. Hướng xử lý kiến nghị

**Tiếp nhận có điều kiện phần kiểm kê R02; yêu cầu một đợt R02B chỉ đọc, tập trung khắc phục các mục P0/P1 nêu trên, không làm lại R01/R02 đã có chứng cứ.** Chưa duyệt pilot, build, ghi hình, lập trình Video Factory, đăng YouTube. Chỉ bắt đầu bước tiếp sau khi Chủ dự án chấp thuận phạm vi và nghiệm thu lại.
