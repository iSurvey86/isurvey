# YÊU CẦU KIỂM TOÁN BỔ SUNG R02B — iSurvey Video Factory

**Đường dẫn repository:** `D:\AIProject\isurvey`  
**Đầu vào:** R01, R02 và báo cáo `ISURVEY_THAM_DINH_DOC_LAP_R02_2026-11-10.md`.  
**Đầu ra:** tạo thư mục **mới** `docs/audits/2026-11-10_ISURVEY_VIDEO_FACTORY_SOURCE_AUDIT_R02B/` (không sửa đè báo cáo R01/R02).  
**Phạm vi:** KIỂM TOÁN TĨNH CHỈ ĐỌC; không triển khai Video Factory.

## Nhiệm vụ bắt buộc

### 01. Chốt danh tính mã nguồn và so sánh hai mốc

Ghi `git rev-parse HEAD`, nhánh, `git status --porcelain -uall`, `git diff --name-only` trước và sau. Giải thích sự khác nhau giữa R01 HEAD `53c5eb4644f2dbc0f736e03098c749197a81a93e` và R02 HEAD `3a16cb3959dc4e65c08f77b6de26669b309739cd` bằng danh sách tệp/đường vào/handler bị ảnh hưởng (lệnh chỉ đọc, không checkout/reset). Nếu HEAD hiện tại lại khác, ghi nhận thêm mốc và xem những kết luận nào cần cập nhật. Không dùng hai mốc như thể cùng snapshot.

### 02. Chuẩn hóa FEATURE ở cấp nghiệp vụ, không đồng nhất với CommandMethod

Đọc các wrapper nằm **ngoài `CommandAliases.cs`**: bắt đầu ít nhất với `ISURVEY_PROFILE_DRAW` ↔ `VEMCD`, `BANGCOC` ↔ `ISURVEY_STATION_LIST`, `ISURVEY_ROUTE_NEW` ↔ `TAOTUYEN`, `ISURVEY_ROUTE_STATIONS` ↔ `PHATSINHCOC`, `ISURVEY_TERRAIN_BUILD` ↔ `XAYMOHINH`. Với từng cặp, so sánh handler và điều kiện gọi thật rồi quyết định `SAME_FEATURE` / `DIFFERENT_FEATURE` / `UNCERTAIN` kèm dẫn chứng file:line.

Đánh giá lại 79 hồ sơ R02; không ép kết quả phải là một con số dự đoán. Dựng bảng `feature_id` ổn định, mã R01, mã R02, tên hành vi, vai trò, lệnh chính, alias cả trong lẫn ngoài `CommandAliases.cs`, UI, trạng thái nguồn và lý do gộp/tách. Tách riêng nhóm admin, support, internal, stub, disabled placeholder. Phân nhóm đúng theo nghiệp vụ; kiểm tra những ví dụ R02 đang xếp sai: `ISURVEY_UPDATE_GE`, `DAODAUTUYEN`, `ISURVEY_STATION_ADD_ONE`, `ISURVEY_TERRAIN_ADD`.

### 03. Hoàn thành bản đồ UI không bỏ sót

Lập ma trận toàn bộ 125 command declarations, 61 Ribbon buttons, 91 XAML Click declarations và 8 Palette run references R02 đã phát hiện; bổ sung các điểm vào dynamic/context menu/handler nếu source chứng minh có. Với XAML: xác định handler code-behind/service và hành vi, ánh xạ feature hoặc lý do loại (`CLOSE/CANCEL/SETTINGS/INTERNAL/UNRESOLVED`). Giải thích số điểm vào trùng nhau. Tuyệt đối không suy ra mỗi nút UI là một feature mới.

### 04. Truy vết thật từng tính năng qua service

Đối với mọi feature có thể hướng dẫn người dùng, không dừng ở tên class `PointDrawService`, `DgnImportService`, `RouteStore`, `ProfileDrawService` hay `FrameService`. Đọc logic và nhánh gọi liên quan có thể kiểm chứng. Mỗi hồ sơ có:
- Kích hoạt command/UI → handler → service/helper → kết quả hoặc side effect; dẫn chứng `file:line` cho các mắt xích quan trọng;
- Dữ liệu đầu vào thực, kiểu CAD/file và điều kiện tiên quyết; kết quả đầu ra và hậu điều kiện có thể đo; nhánh lỗi/exception đáng kể;
- Quyền/ẩn dữ liệu, hành động destructive, phụ thuộc môi trường và tình huống không an toàn;
- MASTER/WORK COPY/REFERENCE đề xuất đúng với hành vi thật, giới hạn nguồn chưa xác minh;
- Kiến nghị ghép bài/video, độ khó quay và trạng thái **runtime=NOT_TESTED**.

Ưu tiên chi tiết D2C, VEMCD, UAVCLIP, NHAPDIEM, XUATDIEM và các tính năng phụ thuộc cùng service; nhưng **không bỏ qua** những feature còn lại. Nếu không đủ thời gian, chia thành các đợt con R02B-01/02… có bảng hoàn thành theo ID; tuyệt đối không báo 100% nếu còn service trọng yếu chưa truy vết.

### 05. Sửa lại cấp bằng chứng và kiểm tra độc lập

Không tự gán `SOURCE_BEHAVIOR_REVIEWED` chỉ vì thân method dài >40 ký tự và có từ khóa. Dùng các mức phân biệt `DECLARATION_FOUND`, `METHOD_BODY_SCANNED`, `HANDLER_TRACE_COMPLETE`, `SERVICE_CHAIN_VERIFIED_STATIC`, `STUB_ONLY`, `NOT_ENOUGH_EVIDENCE`; ghi chính xác quy tắc để người kiểm toán có thể tái kiểm. Runtime không thử. Tăng cường bằng chứng kiểm tra mẫu: `file:line`, call-site, branch, side effect và hậu điều kiện, không chỉ chuỗi `CommandMethod` xuất hiện đâu đó trong file.

### 06. Tự kiểm và bàn giao

- CSV UTF-8, ID duy nhất, link tới hồ sơ tồn tại, đếm/quan hệ toàn bộ điểm vào tự khớp, alias gộp/tách có căn cứ.
- Có bảng sai khác R01→R02→R02B, các phần source còn chưa đọc và blockers nghiêm trọng với từng feature.
- Có thống kê bằng chứng đã kiểm thủ công và thống kê chỉ do script đưa ra.
- Có Git before/after và chứng cứ không thay đổi tracked code; chú thích thay đổi có sẵn trước đợt (kể cả tracked R01 ZIP đang báo xóa trong Git ở R02).
- Xuất bản báo cáo trình Chủ dự án chỉ nêu kết quả đúng mức, có cột `CHƯA ĐỦ BẰNG CHỨNG` nếu cần.
- Nén toàn bộ thư mục R02B thành ZIP và **DỪNG** để trình Hội đồng/Chủ dự án.

## Giới hạn tuyệt đối

Không chỉnh sửa C#/XAML/config/`iSurvey.bundle`/DWG/DGN; không chạy build, test, CAD, NETLOAD, chương trình video, đăng YouTube; không cài dependency, không sửa quyền Windows, không tự commit/push/pull/reset, không đọc hay xuất bí mật/OTP/token/license/dữ liệu công trình. Chỉ tạo tệp báo cáo mới trong thư mục R02B. Không cho phép ghi file ngoài thư mục đó, kể cả tạo Prompt Master mới. Nếu nguồn bị thay đổi trong khi đọc, báo sự khác biệt, không tự sửa. **Kiểm toán R02B không đồng nghĩa được phê duyệt triển khai.**
